<script>
  AOS.init();
</script>
